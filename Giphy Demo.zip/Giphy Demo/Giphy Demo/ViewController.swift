//
//  ViewController.swift
//  Giphy Demo
//
//  Created by Prakash on 21/06/20.
//  Copyright © 2020 Prakash. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyGif
import Kingfisher

var BaseURL = "https://api.giphy.com/v1/gifs/"

class ViewController: UIViewController,UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UISearchBarDelegate {

    @IBOutlet weak var clvImages: UICollectionView!
   
    var arrImages = [Any]()
    var limit = 10
    
    var arrMoreData = [String:AnyObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        GetGIF(limit)
    }

    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    @IBAction func press_btnRefresh(_ sender: UIBarButtonItem) {
  
    }
    
    func GetGIF(_ count : Int) {
        let url =  "\(BaseURL)trending?api_key=VQxMQGPpghbSQlA4f0srCCUYWKiZuweq&limit=\(count)&rating=G"
           //if you want to add paramter

           AF.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default)
               .responseJSON { response in
                   // print(response)
                   //to get status code
                   if let status = response.response?.statusCode {
                       switch(status){
                       case 200:
                        print("example success")
                        
                        //to get JSON return value
                        if let array = response.value as? NSDictionary
                        {
//                            self.arrMoreData = array as! [String : AnyObject]
                            self.arrImages = array["data"] as! [Any]
                            
                            self.clvImages.reloadData()
                        }
                        
                       default:
                           print("error with response status: \(status)")
                       }
                   }
           }
    }
    
    func SearchData(_ strWord: String)
    {
        self.arrImages.removeAll()
        
        let url =  "\(BaseURL)search?api_key=VQxMQGPpghbSQlA4f0srCCUYWKiZuweq&q=\(strWord)&limit=\(limit)&offset=0&rating=G&lang=en"
        //if you want to add paramter
        
        AF.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default)
            .responseJSON { response in
                // print(response)
                //to get status code
                if let status = response.response?.statusCode {
                    switch(status){
                    case 200:
                        print("example success")
                        
                        //to get JSON return value
                        if let array = response.value as? NSDictionary
                        {
                            self.arrImages = array.value(forKey: "data") as! [Any]
                            
                            self.clvImages.reloadData()
                        }
                        
                    default:
                        print("error with response status: \(status)")
                    }
                }
        }
    }
    
    //MARK:- COLLECTION VIEW METHOD
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        arrImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "gifCVCell", for: indexPath) as! gifCVCell
                
        let dict = arrImages[indexPath.row] as! [String:AnyObject]
        
        if let imgURL = URL(string: (((dict["images"] as! NSDictionary).value(forKeyPath: "fixed_height_small") as! NSDictionary).value(forKey: "url") as? String)!)
        {
            cell.imgGIF.kf.indicatorType = .activity
            cell.imgGIF.kf.setImage(with: imgURL)
            
//            cell.imgGIF.setGifFromURL(imgURL)
        }
//        else{
//            cell.imgGIF.kf.indicatorType = .activity
//            cell.imgGIF.kf.setImage(with: URL(string: ""))
//        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: collectionView.frame.size.width/3, height: collectionView.frame.size.width/3)
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        
        if indexPath.row == arrImages.count - 1
        {
            limit = limit + 10
            
            GetGIF(limit)
        }
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        self.view.endEditing(true)
    }
    
    //MARK:- Search Data
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchBar.text != ""
        {
            SearchData(searchText)
        }else{
            GetGIF(limit)
        }
        
    }
}

