//
//  gifCVCell.swift
//  Giphy Demo
//
//  Created by Prakash on 21/06/20.
//  Copyright © 2020 Prakash. All rights reserved.
//

import UIKit

class gifCVCell: UICollectionViewCell {
    
    @IBOutlet weak var imgGIF: UIImageView!
}
